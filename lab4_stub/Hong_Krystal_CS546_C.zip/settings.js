export const mongoConfig = {
  // serverUrl: 'mongodb://localhost:27017/',
  serverUrl: 'mongodb://127.0.0.1:27017/',
  database: 'Krystal_Hong_lab4'
};
